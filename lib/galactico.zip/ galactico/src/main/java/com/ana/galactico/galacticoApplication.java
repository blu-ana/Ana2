package com.ana.galactico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class galacticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(galacticoApplication.class, args);
	}

}
